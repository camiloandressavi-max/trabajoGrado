/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EMPRESA;

/**
 *
 * @author Camilo Salazar
 */
public class Tiquete {
    
    private String idtiquet;
    private int silla;
    private float valorpagado;
    private String estadotiquet;
    private Pasajero myPasajero;
    private Salida mySalida;

    public Tiquete(String idtiquet, int silla, float valorpagado, String estadotiquet, Pasajero myPasajero, Salida mySalida) {
        myPasajero  = null;
        mySalida    = null;
        this.idtiquet = idtiquet;
        this.silla = silla;
        this.valorpagado = valorpagado;
        this.estadotiquet = estadotiquet;
        this.myPasajero = myPasajero;
        this.mySalida = mySalida;
    }

    public String getIdtiquet() {
        return idtiquet;
    }

    public void setIdtiquet(String idtiquet) {
        this.idtiquet = idtiquet;
    }

    public int getSilla() {
        return silla;
    }

    public void setSilla(int silla) {
        this.silla = silla;
    }

    public float getValorpagado() {
        return valorpagado;
    }

    public void setValorpagado(float valorpagado) {
        this.valorpagado = valorpagado;
    }

    public String getEstadotiquet() {
        return estadotiquet;
    }

    public void setEstadotiquet(String estadotiquet) {
        this.estadotiquet = estadotiquet;
    }

    public Pasajero getMyPasajero() {
        return myPasajero;
    }

    public void setMyPasajero(Pasajero myPasajero) {
        this.myPasajero = myPasajero;
    }

    public Salida getMySalida() {
        return mySalida;
    }

    public void setMySalida(Salida mySalida) {
        this.mySalida = mySalida;
    }

    @Override
    public String toString() {
        return "Tiquete{" + "idtiquet=" + idtiquet + ", silla=" + silla + ", valorpagado=" + valorpagado + ", estadotiquet=" + estadotiquet + ", myPasajero=" + myPasajero + ", mySalida=" + mySalida + '}';
    }


    
}