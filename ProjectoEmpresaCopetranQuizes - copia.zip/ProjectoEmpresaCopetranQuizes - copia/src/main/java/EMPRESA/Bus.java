/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EMPRESA;

/**
 *
 * @author Camilo Salazar
 */
public class Bus {
    private String placa;
    private String tipo;
    private int[] asientos;
    private String estado;

    public Bus(String placa, String tipo, int[] asientos, String estado) {
        this.placa = placa;
        this.tipo = tipo;
        this.asientos = asientos;
        this.estado = estado;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int[] getAsientos() {
        return asientos;
    }

    public void setAsientos(int[] asientos) {
        this.asientos = asientos;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Bus{" + "placa=" + placa + ", tipo=" + tipo + ", asientos=" + asientos + ", estado=" + estado + '}';
    }

    
    
    
    
}