/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EMPRESA;

/**
 *
 * @author Camilo Salazar
 */
public class Ruta {
    private String codigo;
    private String origen;
    private String Destino;
    private String tarifaBase;

    public Ruta(String codigo, String origen, String Destino, String tarifaBase) {
        this.codigo = codigo;
        this.origen = origen;
        this.Destino = Destino;
        this.tarifaBase = tarifaBase;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getOrigen() {
        return origen;
    }

    public void setOrigen(String origen) {
        this.origen = origen;
    }

    public String getDestino() {
        return Destino;
    }

    public void setDestino(String Destino) {
        this.Destino = Destino;
    }

    public String getTarifaBase() {
        return tarifaBase;
    }

    public void setTarifaBase(String tarifaBase) {
        this.tarifaBase = tarifaBase;
    }

    @Override
    public String toString() {
        return "Ruta{" + "codigo=" + codigo + ", origen=" + origen + ", Destino=" + Destino + ", tarifaBase=" + tarifaBase + '}';
    }
    
    
}
