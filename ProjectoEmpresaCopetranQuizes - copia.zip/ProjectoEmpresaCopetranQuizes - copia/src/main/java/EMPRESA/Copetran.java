/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package EMPRESA;
import java.util.ArrayList;
/**
 *
 * @author Camilo Salazar
 */
public class Copetran {
    
    private ArrayList<Bus> myBus = new ArrayList<>();
    private ArrayList<Ruta> myRuta = new ArrayList<>();
    private ArrayList<Salida> mySalida = new ArrayList<>();
    private ArrayList<Pasajero> myPasajero = new ArrayList<>();
    private ArrayList<Tiquete> myTiquete = new ArrayList();

    public Copetran() {
        this.myBus= null;
        this.myRuta=null;
        this.myPasajero=null;
        this.myRuta=null;
        this.myTiquete=null;
    }

    
    
    
    
    
    public String crearRuta(){
        
        return null;
    }
    
    public String  crearSalida(){
        
        return null;
    }
    
    public String registrarBus(){
        
        return null;
    }
    
    public String listarBus(){
        
        
        return null;
    }
    
    public String listarRuta(){
        
        return null;
    }
    
    public String listarSalida(){
        
        return null;
    }
    
     public String  cancelarSalida(){
         
         
         return null;
     }
     public String  ventaDelPasaje(){
         
         return null;
     }
     public String  ventaPasajeIdaVuelta(){
         
         
         return null;
     }         
     
     public String generarReporte(){
         
         return null;
     }
    
     public void abrirCaja(){
         
         
     }
     public void cargarDatosBase(){
         
         
     }
     
     public float ingresoNeto(){
         
         return 0.0f;
                
        }
    
     private float calcularPrecio(){
         
         return 0.0f;
     }
     
     private void registrarVenta(){
         
         
     }
     
     private void registrarReembolso(){
         
         
         
     }
     
     
     
     
     
}
