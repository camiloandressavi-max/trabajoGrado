/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EMPRESA;

/**
 *
 * @author Camilo Salazar
 */
public class Salida {
    private String idsalida;
    private String fecha;
    private String hora;
    private int asientocomprado;
    private Ruta myRuta;
    private Bus myBus;

    public Salida(String idsalida, String fecha, String hora, int asientocomprado, Ruta myRuta, Bus myBus) {
        myRuta= null;
        myBus= null;
        this.idsalida = idsalida;
        this.fecha = fecha;
        this.hora = hora;
        this.asientocomprado = asientocomprado;
        this.myRuta = myRuta;
        this.myBus = myBus;
    }

    public String getIdsalida() {
        return idsalida;
    }

    public void setIdsalida(String idsalida) {
        this.idsalida = idsalida;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public int getAsientocomprado() {
        return asientocomprado;
    }

    public void setAsientocomprado(int asientocomprado) {
        this.asientocomprado = asientocomprado;
    }

    public Ruta getMyRuta() {
        return myRuta;
    }

    public void setMyRuta(Ruta myRuta) {
        this.myRuta = myRuta;
    }

    public Bus getMyBus() {
        return myBus;
    }

    public void setMyBus(Bus myBus) {
        this.myBus = myBus;
    }

    @Override
    public String toString() {
        return "Salida{" + "idsalida=" + idsalida + ", fecha=" + fecha + ", hora=" + hora + ", asientocomprado=" + asientocomprado + ", myRuta=" + myRuta + ", myBus=" + myBus + '}';
    }

   
   
}